<?php
    include "../assets.php";
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-1" style="height:100vh;background-color:#4C6AB7; border-radius:0px 30px 30px 0px;margin-left:-30px;">
            <ul class="navbar-nav fs-4 text-center">
                <li><a href="" class="text-white"><i class="bi bi-house"></i></a></li>
                <li><a href="" class="text-white"><i class="bi bi-clock-history"></i></a></li>
                <li><a href="" class="text-white"><i class="bi bi-file-earmark-plus"></i></a></li>
            </ul>
        </div>
    </div>
</div>