<?php
    include "../assets.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .placeholder::-webkit-input-placeholder{
	        color: #5095CF !important;
        }
    </style>
</head>
<body>
    <header>
        <?php
            include "../navside/navbar.php";
        ?>
    </header>
    <div class="container">
    <div class="row">
        <div class="col-6" style="margin-top:-50px;">
            <img src="../assets/img/bg-login.png" class="img-fluid" alt="">
        </div>
        <div class="col-6 row ">
            <form action="" method="">
                <div class="row ms-5">
                <div class="col-12 w-75">
                    <p class="fw-bold " style="color:#E18139;font-size:19px;">Nama lengkap</p>
                    <input type="text" name="" class="placeholder ps-3 form-control rounded-pill fw-bold" style="background:#ECECEC;margin-top:-18px;" placeholder="nama lengkap">
                </div>
                <div class="col-12 w-75 mt-2">
                    <p class="fw-bold " style="color:#E18139;font-size:19px;">Password</p>
                    <input type="text" name="" class="placeholder ps-3 form-control rounded-pill fw-bold" style="background:#ECECEC;margin-top:-18px;" placeholder="password">
                </div>
                <div class="col-12 w-75">
                    <center>
                        <input type="submit" value="Login Sekarang!" class="fw-bold text-white btn mt-5 w-75 py-2" style="background-color:#5669DB;">
                        <a href="index.php" value="Login Sekarang!" class="fw-bold text-white btn mt-5 w-75 py-2" style="background-color:#5669DB;"></a>
                    </center>
                </div>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>