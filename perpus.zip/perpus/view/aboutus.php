<?php
$status2 = "aktif";
    include "../assets.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <?php include "../navside/navbar.php"; ?>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-5">
                <img src="../assets/img/nene.png" class="img-fluid" style="height:80%;">
            </div>
            <div class="col-7">
                <p class="fw-bold" style="color:#E18139;font-size:20px;">kenapa membaca buku itu penting?</p>
                <p class="lh-sm" style="text-align: justify;">Membaca buku memiliki banyak manfaat untuk perkembangan pribadi seseorang. Pertama-tama, membaca buku dapat meningkatkan keterampilan bahasa dan kosakata seseorang. Dengan membaca buku, kita dapat mempelajari kata-kata baru dan cara penggunaannya dalam kalimat yang benar. Selain itu, membaca buku juga dapat membantu meningkatkan kemampuan membaca dan menulis.</p>
            </div>
            <div class="col-7" style="margin-top:-40px;">
                <p class="fw-bold" style="color:#E18139;font-size:20px;">Masih menggunakan cara Lama untuk membaca Buku?</p>
                <p class="lh-sm" style="text-align: justify;">Semakin majunya teknologi digital membuat banyak layanan yang dulunya hanya bisa dilakukan secara konvensional kini bisa dilakukan secara online. Salah satu contohnya adalah membaca buku. Kini, tak perlu lagi datang ke toko buku atau perpustakaan untuk membeli atau meminjam buku. Cukup dengan mengakses situs-situs yang menyediakan layanan baca buku online, maka kita sudah bisa memperoleh akses ke berbagai macam buku dari berbagai genre. Selain itu, membaca buku secara online juga memberikan kemudahan dalam membawa buku, karena cukup dengan membawa perangkat pintar seperti smartphone atau tablet, kita sudah bisa membaca di mana saja dan kapan saja tanpa harus membawa buku fisik yang berat.</p>
            </div>
            <div class="col-5" style="margin-top:-10px;">
                <img src="../assets/img/kake.png" class="img-fluid" style="height:80%;">    
            </div>
            </div>
    </div>
</body>
</html>