<?php
$status1 = "aktif";
    include "../assets.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <?php
        include "../navside/navbar.php"
        ?>
    </header>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <p class="fw-bold" style="color:#E18139;font-size:35px;">Halo Sobat</p>
                <p class="fw-bold" style="color:#4C6AB7;font-size:62px;margin-top:-53px;margin-left:-3px;">Perpusline</p>
                <div style="margin-top:150px;">
                    <p class="opacity-50" style="color:#E18139;">Belum memiliki Akun?</p>
                    <button type="submit" class="py-2 btn w-75 fw-bold text-white" style="background:#5669DB;margin-top:-17px;">Daftar Sekarang</button>
                </div>
            </div>
            <div class="col-6" style="margin-top:-25px;">
                <img src="../assets/img/human.jpg" class="img-fluid" alt="">
            </div>
        </div>
    </div>
</body>
</html>