<?php
    include "../assets.php";
?>
<div class="container">
    <div class="row">
        <div class="col-6">
            <p class="fs-2" style="color:#E18139;">Perpusline</p>
        </div>  
        <div class="col-6 d-flex justify-content-end">
            <nav class="navbar">
                <div class="container-fluid">
                    <form class="d-flex" role="search">
                        <input style="background-color:#ECECEC;color:#535353;" class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <div class="mt-2" style="margin-left:-30px;"><i class="bi bi-search"></i></div>
                        <button class="btn btn-outline-success ms-3" type="submit">Search</button>
                    </form>
                </div>
            </nav>
        </div>
    </div>
</div>

