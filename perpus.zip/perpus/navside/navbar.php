<?php
    include "../assets.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
    <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4">
        <div class="col-md-3 mb-2 mb-md-0">
            <a href="/" class="d-inline-flex link-body-emphasis text-decoration-none">
                <img src="../assets/img/logo.jpg" alt="" style="width:90px;height:90px;">
                <span class="mt-4 fs-3" style="color:#E18139;">Perpusline</span>
            </a>
        </div>

        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0 d-flex">
            <?php
                if (isset($status1) && ($status1="aktif")) {
                ?>
                  <li class="px-4" style="background-color:#5669DB;height:100px;margin-top:-30px;border-radius:0px 0px 15px 15px ;"><a href="../view/dashboard.php" style="margin-top:40px;" class="nav-link px-2 fw-bold text-white">Home</a></li>
                <?php
                }
                else {
                    ?>
                    <li class="px-4"><a href="../view/dashboard.php" class="nav-link px-2 opacity-50" style="color:#5095CF;">Home</a></li>
                    <?php
                }
            ?>
            
            <?php
                if (isset($status2) && ($status2="aktif")) {
                ?>
                    <li class="px-4" style="background-color:#5669DB;height:100px;margin-top:-30px;border-radius:0px 0px 15px 15px ;"><a href="../view/aboutus.php" style="margin-top:40px;" class="nav-link px-2 fw-bold text-white">About Us</a></li>
                <?php
                }
                else {
                    ?>
                    <li class="px-4" ><a href="../view/aboutus.php" class="nav-link px-2 opacity-50" style="color:#5095CF;">About Us</a></li>
                    <?php
                }
            ?>
            
            <?php
                if (isset($status3) && ($status3="aktif")) {
                ?>
                    <li class="px-4" style="background-color:#5669DB;height:100px;margin-top:-30px;border-radius:0px 0px 15px 15px ;"><a href="#" style="margin-top:40px;" class="nav-link px-2 fw-bold text-white">Register</a></li>
                <?php
                }
                else {
                    ?>
                    <li class="px-4" ><a href="../view/register.php" class="nav-link px-2 opacity-50" style="color:#5095CF;">Register</a></li>
                    <?php
                }
            ?>
            <li class="px-4" ><a href="../view/login.php" class="nav-link px-2 fw-bold text-decoration-underline" style="color:#385EC0;">Login</a></li>
        </ul>
    </header>
</div>

</body>
</html>